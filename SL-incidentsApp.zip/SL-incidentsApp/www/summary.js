var summary = [
    {
        "className": ".FRP",
        "project": "FRP",
        "data": [
            {
                "x": 2,
                "y": 13
            },
            {
                "x": 3,
                "y": 15
            },
            {
                "x": 4,
                "y": 17
            },
            {
                "x": 5,
                "y": 24
            },
            {
                "x": 6,
                "y": 26
            }
        ]
    },
    {
        "className": ".Database",
        "project": "Database",
        "data": [
            {
                "x": 2,
                "y": 22
            },
            {
                "x": 3,
                "y": 27
            },
            {
                "x": 4,
                "y": 34
            },
            {
                "x": 5,
                "y": 28
            },
            {
                "x": 6,
                "y": 30
            }
        ]
    },
    {
        "className": ".Fusion",
        "project": "Fusion",
        "data": [
            {
                "x": 2,
                "y": 26
            },
            {
                "x": 3,
                "y": 25
            },
            {
                "x": 4,
                "y": 25
            },
            {
                "x": 5,
                "y": 19
            },
            {
                "x": 6,
                "y": 23
            }
        ]
    },
    {
        "className": ".EBS",
        "project": "EBS",
        "data": [
            {
                "x": 2,
                "y": 23
            },
            {
                "x": 3,
                "y": 14
            },
            {
                "x": 4,
                "y": 13
            },
            {
                "x": 5,
                "y": 20
            },
            {
                "x": 6,
                "y": 15
            }
        ]
    },
    {
        "className": ".SAS",
        "project": "SAS",
        "data": [
            {
                "x": 2,
                "y": 13
            },
            {
                "x": 3,
                "y": 13
            },
            {
                "x": 4,
                "y": 34
            },
            {
                "x": 5,
                "y": 25
            },
            {
                "x": 6,
                "y": 37
            }
        ]
    }
];