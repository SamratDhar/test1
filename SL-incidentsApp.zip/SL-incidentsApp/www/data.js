var results = {};

results[2] =

    [
        {
            "Project": "FRP",
            "Critical": 3,
            "Modarate": 6,
            "Level2": 4,
            "Total": 13
        },
        {
            "Project": "Database",
            "Critical": 8,
            "Modarate": 7,
            "Level2": 7,
            "Total": 22
        },
        {
            "Project": "Fusion",
            "Critical": 10,
            "Modarate": 11,
            "Level2": 5,
            "Total": 26
        },
        {
            "Project": "EBS",
            "Critical": 11,
            "Modarate": 8,
            "Level2": 4,
            "Total": 23
        },
        {
            "Project": "SAS",
            "Critical": 6,
            "Modarate": 5,
            "Level2": 2,
            "Total": 13
        }
    ];

results[3] =

    [
        {
            "Project": "FRP",
            "Critical": 6,
            "Modarate": 5,
            "Level2": 4,
            "Total": 15
        },
        {
            "Project": "Database",
            "Critical": 11,
            "Modarate": 8,
            "Level2": 8,
            "Total": 27
        },
        {
            "Project": "Fusion",
            "Critical": 10,
            "Modarate": 10,
            "Level2": 5,
            "Total": 25
        },
        {
            "Project": "EBS",
            "Critical": 7,
            "Modarate": 5,
            "Level2": 2,
            "Total": 14
        },
        {
            "Project": "SAS",
            "Critical": 6,
            "Modarate": 3,
            "Level2": 4,
            "Total": 13
        }
    ];


results[4] =

    [
        {
            "Project": "FRP",
            "Critical": 7,
            "Modarate": 3,
            "Level2": 7,
            "Total": 17
        },
        {
            "Project": "Database",
            "Critical": 10,
            "Modarate": 16,
            "Level2": 8,
            "Total": 34
        },
        {
            "Project": "Fusion",
            "Critical": 13,
            "Modarate": 5,
            "Level2": 7,
            "Total": 25
        },
        {
            "Project": "EBS",
            "Critical": 5,
            "Modarate": 4,
            "Level2": 4,
            "Total": 13
        },
        {
            "Project": "SAS",
            "Critical": 10,
            "Modarate": 13,
            "Level2": 11,
            "Total": 34
        },
    ];

results[5] =

    [
        {
            "Project": "FRP",
            "Critical": 7,
            "Modarate": 10,
            "Level2": 7,
            "Total": 24
        },
        {
            "Project": "Database",
            "Critical": 11,
            "Modarate": 11,
            "Level2": 6,
            "Total": 28
        },
        {
            "Project": "Fusion",
            "Critical": 2,
            "Modarate": 8,
            "Level2": 9,
            "Total": 19
        },
        {
            "Project": "EBS",
            "Critical": 8,
            "Modarate": 6,
            "Level2": 6,
            "Total": 20
        },
        {
            "Project": "SAS",
            "Critical": 9,
            "Modarate": 9,
            "Level2": 7,
            "Total": 25
        }
    ];


results[6] =
    [
        {
            "Project": "FRP",
            "Critical": 14,
            "Modarate": 7,
            "Level2": 5,
            "Total": 26
        },
        {
            "Project": "Database",
            "Critical": 10,
            "Modarate": 13,
            "Level2": 7,
            "Total": 30
        },
        {
            "Project": "Fusion",
            "Critical": 9,
            "Modarate": 8,
            "Level2": 6,
            "Total": 23
        },
        {
            "Project": "EBS",
            "Critical": 3,
            "Modarate": 5,
            "Level2": 7,
            "Total": 15
        },
        {
            "Project": "SAS",
            "Critical": 9,
            "Modarate": 15,
            "Level2": 13,
            "Total": 37
        }
    ];