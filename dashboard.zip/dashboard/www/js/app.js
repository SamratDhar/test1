var app = angular.module('slApp', [ 'googlechart' ]);


// Page 1 Chart 1
app.controller('pg1chart1cntrl', function($scope) {
    var chart1 = {};
    //chart1.type = "PieChart";
	chart1.type = "BarChart";
    chart1.data = [
       ['Tower', 'Actual Cost', 'Surplus'],
        ['FRP', 785, 449],
        ['EBS', 489, 0],
        ['DATABASE', 756, 243],
        ['FUSION', 544, 0],
        ['SAS', 281, 318]
      ];
    //chart1.data.push(['Services',20000]);
    chart1.options = {
        //displayExactValues: true,
		'isStacked': true,
        width: '100%',
        height: '100%',
        //is3D: true,
        //chartArea: {left:10,top:10,bottom:0,height:"100%"}
		legend: { position: "none" },
		chartArea: {left: "15%", top: "1%",height: "90%", width: "100%"},
    };

    $scope.chart = chart1;
});


// Page 1 Chart 2
app.controller('pg1chart2cntrl', function($scope) {
    var chart1 = {};
	chart1.type = "BarChart";
    chart1.data = [
       ['Tower', 'Variance', ''],
        ['FRP', -449, 0],
        ['EBS', 0, 489],
        ['DATABASE', -243, 0],
        ['FUSION', 0 , 544],
        ['SAS', -318, 0]
      ];
    
    chart1.options = {
        //displayExactValues: true,
		'isStacked': true,
        width: '100%',
        height: '100%',
        //is3D: true,
        //chartArea: {left:10,top:10,bottom:0,height:"100%"}
		legend: { position: "none" },
		chartArea: {left: "15%", top: "1%",height: "90%", width: "100%"},
    };

    $scope.chart = chart1;
});


// Page 1 Chart 3
app.controller('pg1chart3cntrl', function($scope) {
    var chart1 = {};
	chart1.type = "BarChart";
    chart1.data = [
       ['Tower', 'Variance', ''],
        ['FRP', -35, 0],
        ['EBS', 0, 12],
        ['DATABASE', -29, 0],
        ['FUSION', 0 , 13],
        ['SAS', -32, 0]
      ];
    
    chart1.options = {
        //displayExactValues: true,
		'isStacked': true,
        width: '100%',
        height: '100%',
        //is3D: true,
        //chartArea: {left:10,top:10,bottom:0,height:"100%"}
		legend: { position: "none" },
		chartArea: {left: "15%", top: "1%",height: "90%", width: "100%"},
		//bar: {groupWidth: "25%"}
    };

    $scope.chart = chart1;
});


// Page 2 Chart 1
app.controller('pg2chart1cntrl', function($scope) {
    var chart1 = {};
	chart1.type = "BarChart";
    chart1.data = [
       ['Service', 'Actual Uptime', ''],
        ['88.6%', 88.6, 11.4],
        ['92.1%', 92.1, 7.9],
        ['96.3', 96.3, 3.7],
        ['89.0%', 89.0 , 11.0],
        ['93.7%', 93.7, 6.3]
      ];
    
    chart1.options = {
        //displayExactValues: true,
		'isStacked': true,
        width: '100%',
        height: '100%',
        //is3D: true,
        //chartArea: {left:10,top:10,bottom:0,height:"100%"}
		legend: { position: "none" },
		chartArea: {left: "15%", top: "1%",height: "90%", width: "100%"},
		bar: {groupWidth: "35%"}
    };

    $scope.chart = chart1;
});


// Page 2 Chart 2
app.controller('pg2chart2cntrl', function($scope) {
    var chart1 = {};
	chart1.type = "ComboChart";
    chart1.data = [
       ['Tower', 'FRP', 'HPCM', 'SAS', 'FUSION', 'EBS', 'Average'],
         ['Mar',  165,  938,   522,  998,  450,  614.6],
         ['Apr',  135,  1120,  599,  1268, 288,  682],
         ['May',  157,  1167,  587,  807,  397,  623],
         ['Jun',  139,  1110,  615,  968,  215,  609.4],
         ['Jul',  136,  691,   629,  1026, 366,  569.6]
      ];
    
    chart1.options = {
        //displayExactValues: true,
		//'isStacked': true,
        width: '100%',
        height: '100%',
        //is3D: true,
        chartArea: {left:10,top:10,bottom:0,height:"100%"},
		seriesType: 'bars',
		series: {5: {type: 'line'}},
		//legend: { position: "none" },
		//legends: true,
		chartArea: {left: "15%", top: "1%",height: "90%", width: "100%"}	
		//bar: {groupWidth: "35%"}
		
		//}
    };

    $scope.chart = chart1;
});

// Page 2 Chart 3
app.controller('pg2chart3cntrl', function($scope) {
    var chart1 = {};
	chart1.type = "BarChart";
    chart1.data = [
       ['Service', 'Progress', ''],
        ['98.6%', 98.6, 1.4],
        ['99.1%', 99.1, 0.9],
        ['96.3', 96.3, 3.7],
        ['97.0%', 97.0 , 3.0],
        ['98.7%', 98.7, 1.3]
      ];
    
    chart1.options = {
        //displayExactValues: true,
		'isStacked': true,
        width: '100%',
        height: '100%',
        //is3D: true,
        //chartArea: {left:10,top:10,bottom:0,height:"100%"}
		legend: { position: "none" },
		chartArea: {left: "15%", top: "1%",height: "90%", width: "100%"},
		bar: {groupWidth: "35%"}
    };

    $scope.chart = chart1;
});

// Page 2 Chart 4
app.controller('pg2chart4cntrl', function($scope) {
    var chart1 = {};
	chart1.type = "LineChart";
    chart1.data = [
       ['Tower', 'Current Month', 'Last Month'],
         ['FRP',  98.6,  99.5],
         ['HPCM',  99.1,  98.6],
         ['SAS',  96.3,  93.6],
         ['FUSION',  97.0,  96.3],
         ['EBS',  98.7,  98.3]
      ];
    
    chart1.options = {
        //displayExactValues: true,
		//'isStacked': true,
        width: '100%',
        height: '100%',
        //is3D: true,
        chartArea: {left:10,top:10,bottom:0,height:"100%"},
		chartArea: {left: "15%", top: "1%",height: "90%", width: "100%"},
		title: 'Company Performance',
        curveType: 'function',
        legend: { position: 'bottom' }
		//bar: {groupWidth: "35%"}
		
		//}
    };

    $scope.chart = chart1;
});

// Page 2 Chart 5
app.controller('pg2chart5cntrl', function($scope) {
    var chart1 = {};
	chart1.type = "BarChart";
    chart1.data = [
       ['Service', 'Variance', ''],
        ['35 hrs', 35, 0],
        ['28 hrs', 28, 0],
        ['29 hrs', 29, 0],
        ['13 hrs', 13 , 0],
        ['21 hrs', 21, 0]
      ];
    
    chart1.options = {
        //displayExactValues: true,
		'isStacked': true,
        width: '100%',
        height: '100%',
        //is3D: true,
        //chartArea: {left:10,top:10,bottom:0,height:"100%"}
		legend: { position: "none" },
		chartArea: {left: "15%", top: "1%",height: "90%", width: "100%"},
		bar: {groupWidth: "35%"},
		hAxis: {
			viewWindow: {min: -100, max: 100
		},
		ticks: [-100, -50, 0, 50, 100] // display labels every 25
}
    };

    $scope.chart = chart1;
});
